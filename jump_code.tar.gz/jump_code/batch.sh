#!/bin/sh
doCommand()
{
    hosts=`sed -n '/^[^#]/p' /Users/caochenglong/Documents/pro/lonny/jump_code/ips_s`
    for host in $hosts
    do
        echo ""
        echo -e "\033[33m=========================$host=========================\033[0m"
        ssh -o StrictHostKeyChecking=no -p 10020 $host "$@"
        done
    return 0
}

if [ $# -lt 1 ]
then
    echo "$0 cmd"
    exit
fi

doCommand "$@"
