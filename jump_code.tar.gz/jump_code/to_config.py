#!/usr/local/bin/python3
import os
import sys

import copy
import json
import random

import argparse
from prettytable import PrettyTable

current_path = os.path.abspath(__file__)
pos = current_path.index("lonny")
base_path = os.path.join(current_path[:pos], "lonny/")
sys.path.append(base_path)

from utils.read import load_lines

config_path = os.path.join("/Users/caochenglong/Documents/pro/lonny/jump_code/ips/")
USER = "caochenglong"

def read_config(config_file):
    cf = ConfigParser()
    cf.read(config_file)
    return cf

def listAndSelectOption(options, limit=15, add_search=False):

    ori_options = copy.copy(options)

    options = options[:15]

    if limit < len(ori_options):
        options.append("search ip")
    else:
        add_search = False

    tbl = PrettyTable(["ID", "Option Name"])

    for id_, option in enumerate(options):
        tbl.add_row([id_, option])

    tbl.align["Option Name"] = "l"

    print(tbl)

    while(True):
        try:
            idx = int(input("Please input the vaild option ID:"))
            if idx >= 0 and idx < len(options):
                break
        except Exception as e:
            pass

    if add_search and options[idx] == "search ip":
        while(True):
            try:
                search_ip = input("Please Input the ip for search:")

                if search_ip in ori_options:
                    return search_ip
                print("Input Ip not found ..")
            except Exception as e:
                pass

    return options[idx]

def checkJump(cf):
    options = cf.sections()
    if not "jump" in options:
        print("The config file must have the jump option!\n[jump]\nip = xxx")
        sys.exit(1)
    return cf.get("jump", "ip")

def checkUser(cf):
    options = cf.sections()
    if not "USER" in options:
        print("The config file must have the USER name option!\n[USER]\nuser = xxx")
        sys.exit(1)
    return cf.get("USER", "user")

def writeToSSHConfig(jump_ip, USER, ips):
    jump_host="Host jump\nIdentityFile ~/.ssh/id_rsa\nHostName {}\nPort 26890\nUser {}\n".format(jump_ip, USER)

    ssh_config_file = "{}/.ssh/config".format(os.environ["HOME"])
    os.system("mv {} {}_bak".format(ssh_config_file, ssh_config_file))

    with open(ssh_config_file, "w") as f:
        f.write(jump_host)
        for ip in ips:
            Server_Host= "Host {name}\nHostName {ip}\nUser {USER}\nPort 10020\nStrictHostKeyChecking no\nProxyCommand ssh jump -W %h:%p\n".format(name=ip, ip=ip, USER=USER)
            f.write(Server_Host)

def list_dir(_dir):
    for _, _, files in os.walk(_dir):
        return files

def get_jump_ip():
    with open(os.path.join(config_path, "jump"), "r") as f:
        jump_ips = f.readlines()
        jump_ips = map(lambda x: x.strip("\r\n"), jump_ips)
        jump_ips = list(filter(lambda x: x.strip()[0] != '#', jump_ips))
    return random.choice(jump_ips)

def main():

    ip_cls_lst = list_dir(config_path)
    ip_cls_lst.remove("jump")

    all_ips = []
    for ip_cls in ip_cls_lst:
        ip_real_path = os.path.join(config_path, ip_cls)
        ips = load_lines(ip_real_path)
        ips = list(filter(lambda x: x.strip()[0] != '#', ips))
        all_ips.extend(ips)
    jump_ip = get_jump_ip()

    writeToSSHConfig(jump_ip, USER, all_ips)



if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt as e:
        print("\nExit! See you later!")
